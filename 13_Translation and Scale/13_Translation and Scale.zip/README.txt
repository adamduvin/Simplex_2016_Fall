Adam Duvin
Exercise 04

Mesh objects were stored in a two dimensional array declared at the top of AppClass.h
Mesh objects created in FormShape() at the bottom of AppClass.cpp
All objects deleted in Release()